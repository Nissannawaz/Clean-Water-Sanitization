
import axios from 'axios';


export const fetchAll = async () => {
    try {
        fetch("http://localhost:8080/volunteers/all").then(Response=>Response.json).then((data)=>{
            console.log(data);
        })
    } catch (error) {
    console.error('Error fetching data:', error);
    }
};
export const fetchLogin = async (Name,Password) => {
    try {
    const res=fetchAll();
    const response = await axios.get('your_api_url');
    console.log(response.data);
    } catch (error) {
    console.error('Error fetching data:', error);
    }
};


export const Register = async (postData,Role) => {
try {
    const response = await axios.post('your_api_url', postData);
    console.log(response.status);
} catch (error) {
    console.error('Error posting data:', error);
}
};

