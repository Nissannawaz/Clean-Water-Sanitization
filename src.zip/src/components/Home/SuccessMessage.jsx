
import React from 'react';

const SuccessMessage = () => {
  return (
    <div>
      <h2>Successfully Registered!</h2>
      <p>Your registration was successful. We'll Reach You Soon!</p>
    </div>
  );
};

export default SuccessMessage;
