import { Box, Button, Grid, TextField, Typography, Chip } from "@mui/material";
import './Home.css'
import { useState, useEffect } from "react";
import axios from 'axios'
import { Link } from "react-router-dom";


function Home() {
    const [name, setName] = useState('')
    const [phno, setPhno] = useState('')
    const [add, setAdd] = useState('')

    useEffect(() => {
        axios.get('http://localhost:8080/volunteers/all')
            .then(res => {
                console.log(res.data)
                let Name = res.data[9]
                // console.log(Name.name)
                setName(Name.name)
                setPhno(Name.phonenumber)
                setAdd(Name.address)
            })
    }, [])

    function handleClick() {
        alert("Successfully Registered")
    }

    return (
        <Box className="HomeBox">
            <Box className="RCBox">
                <Typography sx={{ color: 'white' }} variant="h5">Raise the Complaint</Typography>
                <Grid container spacing={2} sx={{ padding: '2%' }}>
                    <Grid item xs={12} md={12}>
                        <TextField fullWidth id="outlined-basic" label="Complaint" variant="outlined" />
                    </Grid>
                    <Grid item xs={12} md={12}>
                        <Link to="/last" className="btn btn-primary " onClick={handleClick} type="submit" sx={{ width: '50%', height: '50px', backgroundColor: 'orangered' }} variant="contained">Send</Link>
                    </Grid>
                </Grid>
            </Box>
            <Box className="CPBox">
                <Typography sx={{ color: 'white' }} variant="h6">Complaint</Typography>
                <Grid container spacing={2} sx={{ padding: '2%' }}>
                    <Grid item xs={6} md={6}>
                        <Typography sx={{ color: 'white' }} variant="h5">Complaint Process</Typography>
                    </Grid>
                    <Grid item xs={6} md={6}>
                        <Chip label="cancelled" color="error" />
                        <Chip label="Waiting...." color="warning" />
                        <Chip label="Assigned" color="success" />
                    </Grid>
                </Grid>
                <Typography sx={{ color: 'white' }} variant="h6">Work Profile</Typography>
                <Grid container spacing={2} sx={{ padding: '2%' }}>
                    <Grid item xs={6} md={6}>
                        <Typography sx={{ color: 'white' }} variant="p">NAME:</Typography>
                    </Grid>
                    <Grid item xs={6} md={6}>
                        <Typography sx={{ color: 'white' }} variant="p">{name}</Typography>
                    </Grid>
                    <Grid item xs={6} md={6}>
                        <Typography sx={{ color: 'white' }} variant="p">PHONE NUMBER:</Typography>
                    </Grid>
                    <Grid item xs={6} md={6}>
                        <Typography sx={{ color: 'white' }} variant="p">+91 {phno}</Typography>
                    </Grid>
                    <Grid item xs={6} md={6}>
                        <Typography sx={{ color: 'white' }} variant="p">ADDRESS:</Typography>
                    </Grid>
                    <Grid item xs={6} md={6}>
                        <Typography sx={{ color: 'white' }} variant="p">{add}</Typography>
                    </Grid>

                </Grid>
            </Box>

        </Box>
    );
}

export default Home;