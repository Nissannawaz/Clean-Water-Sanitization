import { Box, Button, Grid, TextField, Typography, FormControl, InputLabel, MenuItem } from "@mui/material";
import Select, { SelectChangeEvent } from '@mui/material/Select';
import axios from 'axios'
import './Login.css'
import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
// import { fetchAll } from "../../Backend/Connect";
import './Login.jpeg'

function Login() {

    const nav = useNavigate()

    const [LoginOpen, setLoginOpen] = useState(true);
    const [Role, setRole] = useState('');
    const [Name, setName] = useState('');
    const [Email, setEmail] = useState('');
    const [Password, setPassword] = useState('');
    const [Address, setAddress] = useState('');
    const [District, setDistrict] = useState('');
    const [PhNumber, setPhNumber] = useState('');
    const [AadharNumber, setAadharNumber] = useState('');

    const [crtEmail, setCrtEmail] = useState('')
    const [crtPassword, setCrtPassword] = useState('')

    let key = {
        name: Name,
        email: Email,
        password: Password,
        address: Address,
        district: District,
        phonenumber: PhNumber,
        aadharcardnumber: AadharNumber
    }
    console.log(key)

    function handleSubmit(e) {
        e.preventDefault()
        // console.log(key)
        if (Role === "USER") {
            axios.post("http://localhost:8080/watersupply/register", key)
                .then(res => {
                    console.log(res.data)
                    if (res.data === "SuccessFully_Registered") {
                        alert("Registered Successfully")
                        nav('/Home')
                    }
                    else {
                        alert("Values are not inserted")
                    }
                })
        }
        else {
            axios.post("http://localhost:8080/volunteers/register", key)
                .then(res => {
                    // console.log(res.data)
                    if (res.data === "SuccessFully_Registered") {
                        alert("Registered Successfully")
                        nav('/last')
                    }
                    else {
                        alert("Values are not inserted")
                    }
                }).catch(error =>{
                    alert("Registered Successfully")
                        nav('/last')
                })
        }
    }

    // Role === "WORKER"


    // fetchAll();
    const ToggleOpen = () => {
        setLoginOpen(!LoginOpen);
    }

    const handleChange = (event) => {
        setRole(event.target.value);
    };

    function handleLogin(e) {
        e.preventDefault()
        axios.get("http://localhost:8080/watersupply/all")
            .then(res => {
                // console.log(res.data)
                let d = res.data
                let E_mail = d.map((a) => {
                    return a.email
                })
                let Pass = d.map((a) => {
                    return a.password
                })

                if (E_mail.includes(Email) && Pass.includes(Password)) {
                    alert("Correct")
                    nav('/Home')
                }
                else {
                    alert("inCorrect")
                }
            })
        // console.log("hii")
    }

    function handleLogin1(e) {
        e.preventDefault()
        axios.get("http://localhost:8080/volunteers/all")
            .then(res => {
                // console.log(res.data)
                let d = res.data
                let E_mail = d.map((a) => {
                    return a.email
                })
                let Pass = d.map((a) => {
                    return a.password
                })


                if (E_mail.includes(Email) && Pass.includes(Password)) {
                    alert("Correct")
                    nav('/Home')
                }
                else {
                    alert("inCorrect")
                }
            })
        // console.log("hii")
    }
    


    return (
       
            <Box className="LoginBox">
                {LoginOpen ? <>
                    <form onSubmit={handleLogin && handleLogin1}>
                        <Typography sx={{ color: 'white' }} variant="h4">LOGIN</Typography>
                        <Grid container spacing={2} sx={{ padding: '2%' }}>
                            <Grid item xs={12} md={12}>
                                <TextField fullWidth id="outlined-basic" value={Email} onChange={(e) => { setEmail(e.target.value) }} label="Email" variant="outlined" />
                            </Grid>
                            <Grid item xs={12} md={12}>
                                <TextField fullWidth id="outlined-basic" value={Password} onChange={(e) => { setPassword(e.target.value) }} label="Password" variant="outlined" />
                            </Grid>
                            <Grid item xs={12} md={12}>
                                <button sx={{ width: '50%', height: '50px', backgroundColor: 'orangered' }} className="btn btn success" type="submit" variant="contained">Login</button>
                            </Grid>
                            <Grid item xs={12} md={12}>
                                <Button sx={{ width: '50%', height: '50px', backgroundColor: 'orange' }} onClick={ToggleOpen} variant="contained">Sign up</Button>
                            </Grid>
                        </Grid>
                    </form>
                </> :
                    <>
                        <form onSubmit={handleSubmit}>
                            <Typography sx={{ color: 'white' }} variant="h4">SIGN UP</Typography>
                            <Grid container spacing={2} sx={{ padding: '2%' }}>
                                <Grid item xs={6} md={6}>
                                    <TextField fullWidth id="outlined-basic" type="text" value={Name} onChange={(e) => { setName(e.target.value) }} label="Name" variant="outlined" />
                                </Grid>
                                <Grid item xs={6} md={6}>
                                    <TextField fullWidth id="outlined-basic" type="email" value={Email} onChange={(e) => { setEmail(e.target.value) }} label="Email" variant="outlined" />
                                </Grid>
                                <Grid item xs={6} md={6}>
                                    <TextField fullWidth id="outlined-basic" value={Password} onChange={(e) => { setPassword(e.target.value) }} label="Password" variant="outlined" />
                                </Grid>
                                <Grid item xs={6} md={6}>
                                    <TextField fullWidth id="outlined-basic" value={Address} onChange={(e) => { setAddress(e.target.value) }} label="Address" variant="outlined" />
                                </Grid>
                                <Grid item xs={6} md={6}>
                                    <TextField fullWidth id="outlined-basic" value={District} onChange={(e) => { setDistrict(e.target.value) }} label="District" variant="outlined" />
                                </Grid>
                                <Grid item xs={6} md={6}>
                                    <TextField fullWidth id="outlined-basic" value={PhNumber} onChange={(e) => { setPhNumber(e.target.value) }} label="Ph-Number" variant="outlined" />
                                </Grid>
                                <Grid item xs={6} md={6}>
                                    <FormControl fullWidth>
                                        <InputLabel id="demo-simple-select-label">Role</InputLabel>
                                        <Select
                                            labelId="demo-simple-select-label"
                                            id="demo-simple-select"
                                            value={Role}
                                            label="Role"
                                            onChange={handleChange}
                                        >
                                            <MenuItem value={"USER"}>USER</MenuItem>
                                            <MenuItem value={"WORKER"}>WORKER</MenuItem>
                                        </Select>
                                    </FormControl>
                                </Grid>
                                {Role == "WORKER" && <Grid item xs={6} md={6}>
                                    <TextField fullWidth id="outlined-basic" value={AadharNumber} onChange={(e) => { setAadharNumber(e.target.value) }} label="Aadhar Number" variant="outlined" />
                                </Grid>}
                                <Grid item xs={12} md={12}>
                                    <button sx={{ width: '50%', height: '50px', backgroundColor: 'orange' }} type="submit" variant="contained">Sign up</button>
                                </Grid>
                                <Grid item xs={12} md={12}>
                                    <Button sx={{ width: '50%', height: '50px', backgroundColor: 'orangered' }} onClick={ToggleOpen} variant="contained">Login</Button>
                                </Grid>
                            </Grid>
                        </form>
                    </>}
            </Box>
         
    );
}

export default Login;