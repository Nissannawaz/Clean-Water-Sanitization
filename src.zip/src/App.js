import { Container } from '@mui/material';
import './App.css';
import Login from './components/Auth/Login';
import Home from './components/Home/Home';
import { BrowserRouter, Route, Router, Routes } from 'react-router-dom';
import { useEffect } from 'react';
import axios from 'axios'
import SuccessMessage from './components/Home/SuccessMessage';


function App() {

  return (
    <BrowserRouter>
      <Container className='MainContainer'>
        <Routes>
          <Route path='/' element={<Login />} />
          <Route path='/Home' element={<Home />} />
          <Route path='/last' element={<SuccessMessage />} />
        </Routes>
      </Container>
    </BrowserRouter>
  )
}

export default App;
